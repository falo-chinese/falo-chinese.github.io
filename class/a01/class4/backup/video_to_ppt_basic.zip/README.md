# Video to PPT Slide Extractor (學生基礎實作版)

本專案是「銀河 ERP 內訓課程 - Class 04 企業級 AI Agent 自動化實戰」的精選實戰案例。

## 📌 專案目的
學會如何利用 Python 與 OpenCV 讀取影像流，透過矩陣運算與像素差異演算法（Mean Absolute Error, MAE）自動推算投影片「靜止」與「跳頁」的分界點，將簡報影片自動還原成單張的高畫質投影片圖片。

---

## 🏃 快速開始 (Quick Start)

### 1. 安裝必要套件
本專案僅依賴 OpenCV 與 Numpy，無需複雜的深度學習環境：
```bash
pip install opencv-python numpy
```

### 2. 執行擷取腳本
```bash
python3 video_to_ppt_basic.py <影片路徑> [輸出目錄] [抽幀間隔(秒)] [換頁閾值]
```

*   **範例**：
    ```bash
    python3 video_to_ppt_basic.py demo.mp4 output 0.5 8.0
    ```
    程式將在 `output/slides/` 資料夾下輸出 `slide_001.png`、`slide_002.png`... 等投影片。

---

## 🧬 技術演進路徑：從 OpenCV 基礎到 AI 智慧知識庫

為了讓大家了解如何整合多種技術，以下為本專案的「最強完整版」（也就是老師在課堂展示的 Web UI 控制台版本與後續 AI 知識庫）的演進藍圖：

```mermaid
graph TD
    A[影片輸入] --> B[均勻跳幀抽樣]
    B --> C[MAE 像素差異計算]
    C --> D[dHash 差值雜湊去重]
    D --> E[Laplacian 邊緣變異數模糊過濾]
    E --> F[Auto-Crop 自動裁切簡報]
    F --> G[輸出投影片圖片]
    G --> H[OCR 欄位/文字提取]
    H --> I[向量資料庫 Vector DB 建立索引]
    I --> J[LLM RAG 智慧問答/知識庫]
```

### 1. 進階圖像去重：dHash (差值雜湊) + 漢明距離
*   **痛點**：MAE 只比較連續影格的變化。若講師在同一張投影片上移動滑鼠、或者影片有長達數十秒的轉場特效，MAE 就會儲存大量高度相似的垃圾圖片。
*   **解法**：計算投影片的 dHash (將圖片縮小至 9x8 灰階，計算相鄰像素的亮暗差值，轉為一個 64 位元的整數雜湊)。再利用漢明距離（Hamming Distance）比對當前影像雜湊與**過去所有已儲存圖片**的相近度。當漢明距離小於 4 時，判定為重複頁並予以剔除。

### 2. 轉場降噪：Laplacian 邊緣變異數
*   **痛點**：轉場時，相機自動對焦或影片淡入淡出（Fade-in / Fade-out）會導致存到模糊、黑屏或單色的無效畫面。
*   **解法**：
    *   計算 Laplacian 算子的變異數（Variance），若邊緣變異數低於 100，代表畫面邊緣模糊，直接拋棄。
    *   計算灰階平均值，若低於 15，判定為黑畫面拋棄。
    *   計算標準差，若低於 5，判定為純色畫面拋棄。

### 3. 多技術整合：OCR ＋ 知識庫 (KM)
這是本專案最核心的 AI 整合方向：
*   **OCR 文字提取**：
    *   可呼叫離線輕量級的 `PaddleOCR`，或使用 LLM 視覺模型 `Gemini Vision API`（下達 Prompt 直接提取特定欄位，例如標題、條列要點、頁碼）。
*   **知識工程化 (Knowledge Base)**：
    *   將 OCR 提取出的文字經過 `Text Splitter` 切割，並透過 `Embedding Model` 轉為向量。
    *   存入向量資料庫（如 Chroma / FAISS / Qdrant）。
*   **LLM 智慧對話 (RAG)**：
    *   串接 LangChain / LlamaIndex，使用者在前端輸入「高鐵重複報支的規定是什麼？」，系統會自動從 Vector DB 撈出相關的投影片頁面，並由 LLM 整理出精準的文字回答，實現企業知識的高效沈澱與傳承！
