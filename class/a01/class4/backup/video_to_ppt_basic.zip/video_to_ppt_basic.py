#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Falo-Class 04: Video to PPT Slide Extractor (學生基礎版)

本程式為基礎教學範例，示範如何利用 OpenCV 進行影片讀取、影格均勻抽樣、
連續影格平均絕對誤差 (Mean Absolute Error, MAE) 計算，並自動判定投影片切換點。

學員任務與擴充思考：
1. 本版本僅有基礎 MAE 對比，容易因講師游標移動或影片過渡動畫而重複儲存相似畫面。
   思考如何加入「dHash (差值雜湊)」與「漢明距離」進行二次去重（與過去所有存檔比對）。
2. 當畫面切換、投影片尚未對焦或有轉場動畫時，容易存到模糊圖片。
   思考如何加入「Laplacian 邊緣變異數」進行模糊度過濾。
3. 思考如何整合「EasyOCR / Tesseract」進行文字辨識，將簡報內容建置成可搜尋的知識庫 (Knowledge Base)。
"""

import os
import sys
import cv2
import numpy as np

def format_timestamp(seconds: float) -> str:
    """將秒數轉換為 HH:MM:SS 的格式"""
    total_seconds = int(round(seconds))
    mins, secs = divmod(total_seconds, 60)
    hours, mins = divmod(mins, 60)
    return f"{hours:02d}:{mins:02d}:{secs:02d}"

def extract_slides(video_path: str, output_dir: str = "output", frame_interval: float = 0.5, transition_threshold: float = 8.0):
    """
    從簡報影片中智慧擷取投影片。
    
    Args:
        video_path: 影片檔案路徑
        output_dir: 輸出資料夾路徑
        frame_interval: 抽幀間隔時間（秒，預設 0.5 秒）
        transition_threshold: 判定換頁的 MAE 閾值（數值越大越不易觸發，預設 8.0）
    """
    print("=========================================")
    print(" 啟動 Video Slide Extractor (學生基礎版)")
    print(f" 輸入影片: {video_path}")
    print(f" 輸出目錄: {output_dir}")
    print(f" 抽幀間隔: {frame_interval} 秒")
    print(f" 換頁閾值: {transition_threshold}")
    print("=========================================")

    # 建立輸出目錄
    slides_dir = os.path.join(output_dir, "slides")
    os.makedirs(slides_dir, exist_ok=True)

    # 開啟影片檔案
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"錯誤: 無法開啟影片檔案 {video_path}", file=sys.stderr)
        return

    # 取得影片資訊
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    if fps <= 0:
        fps = 25.0  # 若防呆失效，預設為 25.0
        
    duration = total_frames / fps if total_frames > 0 else 0
    print(f"影片解析度: {width}x{height} | FPS: {fps:.2f} | 總長度: {format_timestamp(duration)}")

    # 計算每次跳幀的步長
    frame_step = int(max(1, round(fps * frame_interval)))
    
    # 狀態機與比對變數
    current_frame_idx = 0
    saved_count = 0
    last_saved_frame_gray = None

    while True:
        # 讀取當前影格
        ret, frame = cap.read()
        if not ret or frame is None:
            break
            
        # 計算當前秒數
        current_sec = current_frame_idx / fps
        
        # 轉為灰階並縮小解析度 (128x128)，用於快速且穩健地比對畫面差異
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray_small = cv2.resize(gray, (128, 128), interpolation=cv2.INTER_AREA)
        
        # 初始第一幀：直接判定為第一頁投影片
        if last_saved_frame_gray is None:
            saved_count += 1
            filename = f"slide_{saved_count:03d}.png"
            filepath = os.path.join(slides_dir, filename)
            cv2.imwrite(filepath, frame)
            
            last_saved_frame_gray = gray_small.copy()
            timestamp_str = format_timestamp(current_sec)
            print(f"[{timestamp_str}] 儲存第一張投影片: {filename}")
        else:
            # 計算與前一張儲存影格的平均絕對誤差 (MAE)
            # numpy 運算需轉為 float32 以防溢位
            mae = float(np.mean(np.abs(gray_small.astype(np.float32) - last_saved_frame_gray.astype(np.float32))))
            
            # 若差異大於閾值，判定為換頁
            if mae > transition_threshold:
                saved_count += 1
                filename = f"slide_{saved_count:03d}.png"
                filepath = os.path.join(slides_dir, filename)
                cv2.imwrite(filepath, frame)
                
                last_saved_frame_gray = gray_small.copy()
                timestamp_str = format_timestamp(current_sec)
                print(f"[{timestamp_str}] 偵測到畫面變動 (MAE: {mae:.2f} > {transition_threshold})，儲存投影片: {filename}")
        
        # 跳過接下來的 (frame_step - 1) 幀以加速處理
        for _ in range(frame_step - 1):
            cap.grab()
            current_frame_idx += 1
            
        current_frame_idx += 1

    cap.release()
    print("=========================================")
    print(f" 擷取任務完成！共輸出 {saved_count} 張投影片。")
    print(f" 投影片已儲存至: {slides_dir}")
    print("=========================================")

if __name__ == "__main__":
    # 解析命令列參數
    if len(sys.argv) < 2:
        print("使用說明: python3 video_to_ppt_basic.py <影片路徑> [輸出目錄] [抽幀間隔(秒)] [換頁閾值]")
        print("範例: python3 video_to_ppt_basic.py demo.mp4 output 0.5 8.0")
        sys.exit(1)
        
    video_file = sys.argv[1]
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "output"
    interval = float(sys.argv[3]) if len(sys.argv) > 3 else 0.5
    thresh = float(sys.argv[4]) if len(sys.argv) > 4 else 8.0
    
    if not os.path.exists(video_file):
        print(f"錯誤: 輸入影片檔案不存在: {video_file}", file=sys.stderr)
        sys.exit(1)
        
    extract_slides(video_file, out_dir, interval, thresh)
